import os
# TORCH_HOME environment en '/tmp' es necesario para la escritura en Lambda
os.environ['TORCH_HOME'] = '/tmp'
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import os
import torch
from torchvision.models.detection import fasterrcnn_resnet50_fpn, FasterRCNN_ResNet50_FPN_Weights
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor  
from torchvision.transforms import functional as F
from PIL import Image
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from datetime import datetime
import io
import pandas as pd
import boto3
import csv
from io import StringIO
from googleapiclient.http import MediaIoBaseUpload

                #["dump_truck", "person", "excavator", "loader", "mixer_truck",'steamroller']
class_mapping = ["Vagoneta", "Persona", "Tractor", "Cargador", "Mezcladora",'Aplanadora']
print(class_mapping)

#Definir el umbral de aceptación.
threshold = 0.7
num_classes = 7

FOLDER_ID = '1ID8ZfYqLH3mVGZ5tgArdD0h0Kyt23uAy' #folderID de dIAra Account

#Función para imporar el token.pickle desde S3
def load_pickle_from_s3(bucket_name, object_key):
    s3_client = boto3.client('s3')
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        file_content = response['Body'].read()
        data_stream = io.BytesIO(file_content)
        data = pickle.load(data_stream)
        print("Pickle Cargado")
        return data
    except Exception as e:
        print(f"Falla en cargar pickle desde S3: {e}")
        return None


#Función para guardar archivo en S3 y despues transferir a Google Drive
def save_csv_to_s3_movetogdrive(data):
    s3_client = boto3.client('s3')
    csv_buffer = StringIO()
    data.to_csv(csv_buffer, index=False)

    print(csv_buffer.getvalue(), "primer")
    csv_buffer.seek(0)
    
    today = datetime.now()
    formatted_date = today.strftime('%Y%m%d')
    formatted_date
    print(formatted_date)

    bucket_name = 'contraloriabucket'
    object_key = f'{formatted_date}.csv'
    s3_client.put_object(Bucket=bucket_name, Key=object_key, Body=csv_buffer.getvalue(), ContentType='text/csv')
    print( f' Archivo Cargado satisfactoriamente {object_key} a {bucket_name}')

    #Enviar archivo de S3 a Drive
    s3_client = boto3.client('s3')
    s3_response = s3_client.get_object(Bucket = bucket_name, Key= object_key)
    file_data = s3_response['Body'].read()
    file_stream = io.BytesIO(file_data)
    key = 'token.pickle'
    creds = load_pickle_from_s3(bucket_name, key)
    service = build('drive', 'v3', credentials=creds)
    archivos_folderID = '1x7xRmPfWjQU6C3m9uKOcXD78ns5ZQXhS' #Folder ID de Archivos dIAra
       
    file_metadata = { 'name' : object_key, 'parents': [archivos_folderID] }
    media = MediaIoBaseUpload(file_stream,mimetype='application/octet-stream', resumable=True)

    try:
        file = service.files().create(body=file_metadata,
                                        media_body=media,
                                        fields='id').execute()
        if 'id' in file:
            print(f"Archivo cargado con el ID: {file['id']}")
    except Exception as e:
            print(f"Error: {e}") 

#Función para enlistar a todos los archivos que estan en la carpeta del día y trae las credenciales
def list_files(folder_id):

    today = datetime.now()
    formatted_date = today.strftime('%Y%m%d')
    formatted_date
    print(formatted_date)

    SCOPES = ['https://www.googleapis.com/auth/drive'] 
   
    bucket = 'contraloriabucket'
    key = 'token.pickle'
    creds = load_pickle_from_s3(bucket, key)

    service = build('drive', 'v3', credentials=creds)
    query = f"'{folder_id}' in parents" 
    result = service.files().list(q=query).execute()
    files = result.get('files', [])

    imgs_id = []

    for file in files:
        folder = file['name']
        id_folder = file['id']
        if folder.find('.') == -1:
            if folder == formatted_date:
                query = f"'{id_folder}' in parents and mimeType != 'application/vnd.google-apps.folder'"
                result = service.files().list(q=query).execute()
                imgs = result.get('files', [])
                for img in imgs:
                    if img['name'].find('.') != -1:
                        imgs_id.append([img['name'], img['id']])
                break
    return imgs_id, formatted_date, creds

#Función para leer la arquitectura base de FasterRCNN
def get_model(num_classes, weights_path='./fasterrcnn_resnet50_fpn.pth'):
    model = fasterrcnn_resnet50_fpn(pretrained=False)
    model.load_state_dict(torch.load(weights_path))
    in_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
    return model

#Función principal para inferir en los archivos leidos desde google drive
def main():

    img_inference, formatted_date, creds = list_files(FOLDER_ID)
    print(img_inference)
    if img_inference != []:
        #Cargar el modelo deseado (tomar en cuante las transformaciones)
        model = get_model(num_classes)
        model.load_state_dict(torch.load('./model_epoch_99.pth', map_location=torch.device('cpu')))
        model.eval()
        device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
        model = model.to(device)

        imgs_name = []
        img_clase = []
        img_prob = []
        img_bbox = []

        #Proceso de inferencia y crear archivo de resultados
        service = build('drive', 'v3', credentials=creds)
        for img_name, img_id in img_inference:
            file_metadata = service.files().get_media(fileId=img_id).execute()
            file = io.BytesIO(file_metadata)
            img_pil = Image.open(file)
            img_tensor = F.to_tensor(img_pil).unsqueeze(0)
            image = img_tensor.to(device)
            with torch.no_grad():
                prediction = model(image)
                bboxes = prediction[0]['boxes']
                labels = prediction[0]['labels']
                scores = prediction[0]['scores']
            for bbox, label, score in zip(bboxes, labels, scores):
                if score > threshold:
                    objeto = class_mapping[int(label)-1]
                    print(f"Imagen: {img_name}, se encontro: el objeto {objeto}, bbox {bbox}, score = {score}")
                    imgs_name.append(img_name)
                    img_clase.append(objeto)
                    img_prob.append(score)
                    img_bbox.append(bbox)

        data = pd.DataFrame()
        data["nombre_imagen"] = imgs_name
        data["clase"] = img_clase
        data["probabilidad"] = img_prob
        data["recuadro"] = img_bbox

        save_csv_to_s3_movetogdrive(data)

if __name__ == '__main__':
    main()